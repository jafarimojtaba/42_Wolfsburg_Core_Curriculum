#include "../push_swap.h"

int strsize(char *s)
{
	char *t;
	int i;

	t = s;
	i = 0;
	while (*t)
	{
		i++;
		t++;
	}
	return (i);
}

void run_order(char *order, t_list **stack_a, t_list **stack_b)
{
	if (ft_strncmp(order, "sa", strsize(order)) == 0)
		sx("", *stack_a);
	else if (ft_strncmp(order, "sb", strsize(order)) == 0)
		sx("", *stack_b);
	else if (ft_strncmp(order, "ss", strsize(order)) == 0)
		ss2(*stack_a, *stack_b);
	else if (ft_strncmp(order, "pa", strsize(order)) == 0)
		px2(stack_b, stack_a);
	else if (ft_strncmp(order, "pb", strsize(order)) == 0)
		px2(stack_a, stack_b);
	else if (ft_strncmp(order, "rra", strsize(order)) == 0)
		rrx("", stack_a);
	else if (ft_strncmp(order, "rrb", strsize(order)) == 0)
		rrx("", stack_b);
	else if (ft_strncmp(order, "rrr", strsize(order)) == 0)
		rrr2(stack_a, stack_b);
	else if (ft_strncmp(order, "ra", strsize(order)) == 0)
		rx("", stack_a);
	else if (ft_strncmp(order, "rb", strsize(order)) == 0)
		rx("", stack_b);
	else if (ft_strncmp(order, "rr", strsize(order)) == 0)
		rr2(stack_a, stack_b);
	else
		{
			write(2, "Error\n", 6);
			exit(1);
		}
}

void check_order(char *order, t_list **stack_a, t_list **stack_b)
{
	char *o;
	int i;

	i = 0;
	o = order;
	while (*order)
	{
		if (*order == '\n')
		{
			*order = '\0';
			o = &order[-i];
			i = 0;
			order++;
			run_order(o, stack_a, stack_b);
			// printf("o = %s", o);
			// print_stack(*stack_a, *stack_b);
			continue;
		}
		order++;
		i++;
	}
}

void checker(t_list **stack_a, t_list **stack_b)
{
	char *orders;
	int i;

	i = ft_lstsize(*stack_a);
	orders = ft_calloc(1, sizeof(char));
	while (ft_strjoin(&orders, get_next_line(0)))
		continue;
	check_order(orders, stack_a, stack_b);
	if (check_the_end(*stack_a, *stack_b, i))
		write(1, "OK\n", 3);
	else
		write(1, "KO\n", 3);
	free(orders);
}
