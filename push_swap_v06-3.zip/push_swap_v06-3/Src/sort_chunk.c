/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_a.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mjafari <mjafari@student.42wolfsburg.de>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/13 16:43:23 by mjafari           #+#    #+#             */
/*   Updated: 2021/11/16 18:57:26 by mjafari          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../push_swap.h"

static int	check_sort_till_where(int *org_array, int *sort_array, int *n)
{
	while ((*n) - 1 >= 0)
	{
		if (org_array[*n - 1] == sort_array[*n - 1])
			(*n)--;
		else
			return (sort_array[(*n) / 2]);
	}
	return (sort_array[0]);
}

void	copy_array_chunk(t_list *stack_a, int *m, int *chunk)
{
	int	i;
	int	*org_array;
	int	*sort_array;

	org_array = (int *)ft_calloc(*chunk + 1, sizeof(int));
	sort_array = (int *)ft_calloc(*chunk + 1, sizeof(int));
	i = 0;
	while (i < *chunk)
	{
		org_array[i] = stack_a->content;
		sort_array[i] = stack_a->content;
		stack_a = stack_a->next;
		i++;
	}
	bubblesort(sort_array, *chunk);
	*m = check_sort_till_where(org_array, sort_array, chunk);
	free(org_array);
	free(sort_array);
}

int	check_4_chunk(t_list **stack_a, int m, int *ra)
{
	int	f;
	int	s;
	int th;
	int	l;

	f = (*stack_a)->content;
	s = (*stack_a)->next->content;
	th = (*stack_a)->next->next->content;
	l = ft_lstlast(*stack_a)->content;

	if (s < m && s < f && s < th && s < l)
		sx("sa", *stack_a);
	else if (l < m && l < f && l < s && l < th)
		{
			rrx("rra", stack_a);
			ra--;
		}
	else if (th < m && th < f && th < s && th <= l)
	{
		rx("ra", stack_a);
		sx("sa", *stack_a);
		ra++;
	}
	if (a_is_sorted(*stack_a))
		return (1);
	return (0);
}

void	sort_3_chunk(t_list **stack_a, t_list **stack_b, int m, int chunk)
{
	int	f;
	int	ra;
	int	i;

	i = 0;
	ra = 0;
	while (chunk && ft_lstsize(*stack_a) > 1 && !a_is_sorted(*stack_a))
	{

		while (chunk / 2 < i)
		{
			f = (*stack_a)->content;
			if (check_4_chunk(stack_a, m , &ra))
				return ;
			if (f < m)
				px("pb", stack_a, stack_b, &i);
			else if(chunk / 2)
			{
				rx("ra", stack_a);
				ra++;
			}
		}
		while (chunk < i)
		{
			while (ra)
			{
				f = (*stack_a)->content;
				if (f == m)
					px("pb", stack_a, stack_b, &i);
				rrx("rra", stack_a);
				ra--;
			}
			px("pb", stack_a, stack_b, &i);
		}
	}
}

void	sort_chunk(t_list **stack_a, t_list **stack_b, int chunk)
{
	int	m;
	int	size;
	int b_chunk;

	size = ft_lstsize(*stack_a) + chunk;
	b_chunk = chunk;
	while (!a_is_sorted(*stack_a) && ft_lstsize(*stack_a) < size && chunk > 0)
	{
		copy_array_chunk(*stack_a, &m, &chunk);
		sort_3_chunk(stack_a, stack_b, m, chunk);
		chunk = chunk - chunk / 2;
	}
	sort_b(stack_a, stack_b, &b_chunk, 0);
}
