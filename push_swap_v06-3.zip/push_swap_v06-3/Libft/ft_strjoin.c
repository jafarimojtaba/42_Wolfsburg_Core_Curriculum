/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mjafari <mjafari@student.42wolfsburg.de>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/05/26 00:13:48 by mjafari           #+#    #+#             */
/*   Updated: 2021/05/31 17:24:38 by mjafari          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_strjoin(char **s1, char *s2)
{
	int		i;
	int		j;
	char	*new_str;

	if (!*s1)
		free(*s1);
	if (!s2)
		free(s2);
	if (!*s1 || !s2)
		return (0);
	i = ft_strlen(*s1);
	j = ft_strlen(s2);
	new_str = (char *)malloc(i + j + 1);
	if (!new_str)
	{
		free(*s1);
		free(s2);
		return (0);
	}
	new_str[i + j] = '\0';
	ft_memmove(new_str, *s1, i);
	ft_memmove(&new_str[i], s2, j);
	free(*s1);
	*s1 = new_str;
	free(s2);
	return (1);
}
