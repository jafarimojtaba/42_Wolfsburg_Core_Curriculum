/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mjafari <mjafari@student.42wolfsburg.de>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/05/26 10:58:59 by mjafari           #+#    #+#             */
/*   Updated: 2021/05/26 14:15:50 by mjafari          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char *ft_strtrim(char const *s1, char const *set)
{
	char *new_str;
	int i;
	int j;
	int start;
	int slen;

	slen = ft_strlen(s1);
	i = 0;
	j = 0;
	while (set[j] && s1[i])
	{
		if (s1[i] == set[j])
		{
			i++;
			j = 0;
			continue;
		}
		j++;
	}
	j = 0;
	start = i;
	i = slen - 1;
	while (set[j] && s1[i] && i >= 0)
	{
		if (s1[i] == set[j])
		{
			i--;
			j = 0;
			continue;
		}
		j++;
	}
	new_str = (char *)malloc(i - start + 2);
	new_str[i - start + 1] = '\0';
	if (i == start)
	{
		new_str[0] = 0;
		return (new_str);
	}
	ft_memmove(new_str, &s1[start], i - start + 1);
	return (new_str);
}
